<div>
    <button class="btn btn-sm btn-danger" wire:click="$emit('delete')"><i class="fas fa-check"></i></button>
    <button class="btn btn-sm btn-primary" wire:click="$emit('cancelDelete')"><i class="fas fa-times"></i></button>
</div>
