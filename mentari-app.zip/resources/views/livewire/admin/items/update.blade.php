<div>
    <button class="btn btn-sm btn-danger"><i class="fas fa-check"></i></button>
    <button class="btn btn-sm btn-primary"><i class="fas fa-cancel"></i></button>
</div>
