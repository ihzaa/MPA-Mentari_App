<?php

namespace App\Http\Livewire\Admin\Items;

use Livewire\Component;

class Delete extends Component
{
    public function render()
    {
        return view('livewire.admin.items.delete');
    }
}
