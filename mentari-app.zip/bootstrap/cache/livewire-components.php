<?php return array (
  'admin.items.delete' => 'App\\Http\\Livewire\\Admin\\Items\\Delete',
  'admin.items.index' => 'App\\Http\\Livewire\\Admin\\Items\\Index',
  'admin.items.update' => 'App\\Http\\Livewire\\Admin\\Items\\Update',
  'front.index' => 'App\\Http\\Livewire\\Front\\Index',
);